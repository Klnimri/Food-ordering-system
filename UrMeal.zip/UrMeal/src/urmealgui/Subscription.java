package urmealmain;

//import java.util.*;
import javax.swing.*;
public final class Subscription {
    
 ///////////////////////// Variables declaring
 private String DelivaryTime;
 private double DiscountPer;
 double tax;
 Customer Customer;
 Meals meal;
 ///////////////////////// Variables declaring
 
 
    public Subscription(Meals a){ //1st constractor
        meal = a;
        Customer = meal.Customer;
        SubFin(); //SubFin Method 
       
    }
    
    public Subscription(Customer Customer, Meals meal, double tax, String DelivaryTime, double discount){ //2nd constractor
        SubFin2(tax,DelivaryTime,discount);  //SubFin2 method for the 2nd constractor
        
    }
    public void setCustomer(Customer a){
        Customer = a;
    }
    public void setMeal(Meals meal1){
        meal = meal1;
    }
    public void setTax(double taxValue){
        tax= taxValue;
    }
    public void setDelivaryTime(String a){
        DelivaryTime = a;
    }
    public void setDiscountPer(double DisPer){
        DiscountPer=DisPer;
    }
     public Customer getCustomer(){
        return Customer;
    }
    public Meals getMeal(){
        return meal;
    }
    public double getTax(){
        return tax;
    }
    public String getDelivaryTime(){
        return DelivaryTime;
    }
    public double getDiscountPer(){
       return DiscountPer;
    }
  
 
        public void SubFin(){
        String CouponCode=JOptionPane.showInputDialog("Please enter the coupon code to check the if you are valid for the discount: ");
        
        if(CouponCode.equalsIgnoreCase("UJ")){
            DiscountPer=0.20;
     
            double AfDiscount = meal.getTotalPrice()-(DiscountPer * meal.getTotalPrice());
            meal.setTotalPriceDoub(AfDiscount);
        }
            
       
        tax = 0.15;
        double AfTax = meal.getTotalPrice()-(0.15 * meal.getTotalPrice());
        meal.setTotalPriceDoub(AfTax);
        DelivaryTime="Tomorrow at 3PM";
        double FPrice = meal.getTotalPrice()-((meal.getTotalPrice()*DiscountPer)*tax);
       meal.setTotalPriceDoub(FPrice);
    }
    public void SubFin2(double tx, String DT, double DisCount){
       tax=tx;
       DelivaryTime=DT;
       DiscountPer=DisCount;
       double FPrice = meal.getTotalPrice()-((meal.getTotalPrice()*DiscountPer)*tax);
       meal.setTotalPriceDoub(FPrice);
    }  
    @Override
    public String toString(){ /////////////////////////////////////// toString method
                double DiscountValue = 0.20 * meal.getTotalPrice();

        String Invoice = String.format("\n\t                                  The Invoice\n"+
        meal +'\n'+ Customer + "\n---------------------------------------------------------"+
                "\nThe delivary Time is: "+ DelivaryTime + "\nTax= 15"+
                "\nThe discount if there was: -"+ (int)DiscountValue +"SR"+ "\nThe total price is: "+(int)meal.getTotalPrice()+"SR"+
                "\n\nThank you for using UrMeal application.");
        return Invoice; 
    }
    }



