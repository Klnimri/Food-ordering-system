package urmealmain;                 //Student name: Khalid Nimri      
                                    //Student ID: 2140145             

import java.io.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.util.*;


public class UrMealMain {

   
    
    public static void main(String[] args) throws FileNotFoundException, IOException {
        
        int MenuChoice1 = MainMenu();
        if(MenuChoice1 == 1){
            
            FileWriter fw = new FileWriter("Customers.txt"); //Making an object of the FileWriter Class 
        PrintWriter OutPutFile = new PrintWriter(fw); //Making an object of the PrintWriter class and giving fw as an argument
        
      ///////////////////////////////////////// Making the objects from the classes
        Customer Mohammed = new Customer();
        //Customer mohammed = new Customer("Mohammed",1117827199,0540031222); //another way to make a new object from the customer class
        Meals choice = new Meals(Mohammed);
        Subscription Final_Mohammed = new Subscription(choice);
       JOptionPane.showMessageDialog(null, Final_Mohammed); //Printing the invoice msg 
      ///////////////////////////////////////// Making the objects from the classes
        
        
        ArrayList<Subscription> CustomersArrayList = new ArrayList<>(); // Making an Arraylist to save the Customeres in
        CustomersArrayList.add(Final_Mohammed); // Adding the object to the ArrayList
        //CustomersArrayList.add(         ) //How to add a customer to the ArrayList <<<<<<
         OutPutFile.println(CustomersArrayList); //Printing the Invoice to the file
      
        OutPutFile.close(); //Closing the file to save the information we wrote
        
        System.exit(0); //To Stop the run successfully
        }
        
        else if (MenuChoice1 == 2){
            
        }
             File file= new File("Customers.txt");
        Scanner ReadFromFile = new Scanner(file);
        String Infos;
        while(ReadFromFile.hasNext()){
            Infos = ReadFromFile.nextLine();
            System.out.println(Infos);
        }
        ReadFromFile.close();
        
        
       
        ////////////////////////////////////////
        //Read from file
        
       
            
            ////////////////////////////////////////
        
        /*  /////////////////////////////////// Getters methods for Customer class.
            System.out.println(Mohammed.getCustomerAddress());
            System.out.println(Mohammed.getCustomerAge());
            System.out.println(Mohammed.getCustomerCity());
            System.out.println(Mohammed.getCustomerHeight());
            System.out.println(Mohammed.getCustomerID());
            System.out.println(Mohammed.getCustomerName());
            System.out.println(Mohammed.getCustomerPhoneNumber());
            System.out.println(Mohammed.getCustomerWeight());
            ///////////////////////////////////////////////////// Getters methods for Customer class.
        
            ///////////////////////////////////////////////////// Getters methods for Meals class.
            System.out.println(choice.getAllergicIssues());
            System.out.println(choice.getCalories());
            System.out.println(choice.getCarbs());
            System.out.println(choice.getFat());
            System.out.println(choice.getFoodType());
            System.out.println(choice.getGymGoal());
            System.out.println(choice.getMealChoise());
            System.out.println(choice.getNumberOfMeals());
            System.out.println(choice.getTotalPrice());
            ///////////////////////////////////////////////////// Getters methods for Meals class
        
            ///////////////////////////////////////////////////// Getters methods for Subscription class
            System.out.println(invoiceForMohammed.getCustomer());
            System.out.println(invoiceForMohammed.getDelivaryTime());
            System.out.println(invoiceForMohammed.getDiscountPer());
            System.out.println(invoiceForMohammed.getMeal());
            System.out.println(invoiceForMohammed.getTax());
            ///////////////////////////////////////////////////// Getters methods for Subscription class
        
            
            /////////////////////////////////////////////////// Setters methods for Customer class
            Mohammed.setCustomerAddress("Obhur", Mohammed);
            Mohammed.setCustomerAge(24, Mohammed);
            Mohammed.setCustomerCity("Mecca", Mohammed);
            Mohammed.setCustomerHeight(170, Mohammed);
            Mohammed.setCustomerID(1009871871, Mohammed);
            Mohammed.setCustomerPhoneNumber(0540031222, Mohammed);
            Mohammed.setCustomerWeight(80, Mohammed);
            Mohammed.setCustomerName("Ali", Mohammed);
            ///////////////////////////////////////////////////// Setters methods for Customer class
        
            ///////////////////////////////////////////////////// Setters methods for meals class
            choice.setAllergicIssues("no");
            choice.setCalories(400);
            choice.setCarbs(30);
            choice.setFat(20);
            choice.setFoodType("meet");
            choice.setGymGoal("Bulking");
            choice.setMealChoise(1);
            choice.setNumberOfMeals(2);
            choice.setTotalPrice(100);
             ///////////////////////////////////////////////////// Setters methods for meals class
        
             ///////////////////////////////////////////////////// Setters methods for subscription class
            invoiceForMohammed.setCustomer(Mohammed);
            invoiceForMohammed.setDelivaryTime("3 days at 4PM");
            invoiceForMohammed.setDiscountPer(0.15);
            invoiceForMohammed.setMeal(choice);
            invoiceForMohammed.setTax(0.10);
*/          ///////////////////////////////////////////////////// Setters methods for subscription class
    }
 
        public static int MainMenu(){
            String MainMenuStr = JOptionPane.showInputDialog("Please enter the number of the operation wanted.\n"
                    + "1.New Customer\n2.Read From File");
            int MainMenu=Integer.parseInt(MainMenuStr);
            return MainMenu;
        }
}

