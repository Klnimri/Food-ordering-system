package urmealmain;

import java.util.*;
//import java.io.*;
import javax.swing.JOptionPane;


public class Meals {
    
    ///////////////////////// Variables declaring
    private int MealChoise, NumberOfMeals,Calories,Carbs,Fat;
    private String FoodType, AllergicIssues, GymGoal;
    Customer Customer;
     private double TotalPrice;
     ///////////////////////// Variables declaring
     
     
    public Meals(Customer a){ //1st constractor 
        Customer = a;
       
        MealsMenu(); //meals menu Method 
        
    }
    public Meals(Customer a,int CaloriesNum, int CarbsNum, int FatNum){ //2nd constractor 
        Customer=a;
        MealsMenuWithGivinNutri(CaloriesNum,CarbsNum,FatNum);   //MealsMenuWithGivinNutri method for the 2nd constractor's arg.
    }
    public void setMealChoise(int a){
        MealChoise = a;
    }
    public void setTotalPrice(int a){
        TotalPrice = a;
    }
    public void setTotalPriceDoub(double a){
        TotalPrice = a;
    }
    public void setFoodType(String a){
        FoodType=a;
    }
    public void setAllergicIssues(String a){
        AllergicIssues=a;
    }
    public void setGymGoal(String a){
        GymGoal=a;
    }
    public void setNumberOfMeals(int a){
        NumberOfMeals=a;
    }
    public void setCalories(int a){
        Calories=a;
    }
    public void setCarbs(int a){
        Carbs=a;
    }
    public void setFat(int a){
        Fat=a;
    }
    public int getMealChoise(){
        return MealChoise;
    }
    public double getTotalPrice(){
       return  TotalPrice;
    }
    public String getFoodType(){
        return FoodType;
    }
    public String getAllergicIssues(){
        return AllergicIssues;
    }
    public String getGymGoal(){
        return GymGoal;
    }
    public int getNumberOfMeals(){
        return NumberOfMeals;
    }
    public int getCalories(){
        return Calories;
    }
    public int getCarbs(){
        return Carbs;
    }
    public int getFat(){
        return Fat;
    }
    public void MealsMenu(){
       String MealChoiseStr1 = JOptionPane.showInputDialog("1. 200G of meet with 100G of rice and 50G of pasta and salad&snacks\n"+
                "2. 200G of fried salmon fish and tuna with 100G of rice and sauces and salad&snacks\n"+
                "3. 100G of beans with rice and 100G of salad&Vegetarian snacks and drinks.\n"+
                "4.Make a flexiable meal: \nType \"The number of the meal \" to continue");
        MealChoise=Integer.parseInt(MealChoiseStr1);
        if (MealChoise == 1){
            AllergicIssues=JOptionPane.showInputDialog("Do you have any Allergic issues against any kind of food? ",JOptionPane.YES_NO_OPTION);
            GymGoal=JOptionPane.showInputDialog("Do you have a gym goal? ",JOptionPane.YES_NO_OPTION);
            FoodType=JOptionPane.showInputDialog("Do you prefer a specific kind of food?");
           String NumberOfMealsStr = JOptionPane.showInputDialog("How many meals do you want? ");
           NumberOfMeals=Integer.parseInt(NumberOfMealsStr);
            Calories=700*NumberOfMeals;
            Carbs=50*NumberOfMeals;
            Fat=17*NumberOfMeals;
            TotalPrice = 70 * NumberOfMeals;
            
        }
        else if (MealChoise == 2){
            FoodType=JOptionPane.showInputDialog("Do you prefer a specific kind of food?");
             AllergicIssues=JOptionPane.showInputDialog("Do you have any Allergic issues against any kind of food? ",JOptionPane.YES_NO_OPTION);
             GymGoal=JOptionPane.showInputDialog("Do you have a gym goal? ",JOptionPane.YES_NO_OPTION);
           String NumberOfMealsStr = JOptionPane.showInputDialog("How many meals do you want? ");
           NumberOfMeals=Integer.parseInt(NumberOfMealsStr);
            Calories=640*NumberOfMeals;
            Carbs=64*NumberOfMeals;
            Fat=20*NumberOfMeals;
            TotalPrice =60 * NumberOfMeals;
            
        }
        else if ( MealChoise == 3){
            FoodType=JOptionPane.showInputDialog("Do you prefer a specific kind of food?");
             AllergicIssues=JOptionPane.showInputDialog("Do you have any Allergic issues against any kind of food? ",JOptionPane.YES_NO_OPTION);
             GymGoal=JOptionPane.showInputDialog("Do you have a gym goal? ",JOptionPane.YES_NO_OPTION);
           String NumberOfMealsStr = JOptionPane.showInputDialog("How many meals do you want? ");
           NumberOfMeals=Integer.parseInt(NumberOfMealsStr);
            Calories=550*NumberOfMeals;
            Carbs=70*NumberOfMeals;
            Fat=14*NumberOfMeals;
            TotalPrice =50 * NumberOfMeals;
            
        }
        else if (MealChoise ==4){
            
           String CaloriesStr= JOptionPane.showInputDialog("How many calories do you want per meal? ");
           Calories=Integer.parseInt(CaloriesStr);
           String CarbsStr= JOptionPane.showInputDialog("How many carbs do you need in total? ");
            Carbs=Integer.parseInt(CarbsStr);
           String FatStr= JOptionPane.showInputDialog("How many grams of fat do you need in total? ");
            Fat=Integer.parseInt(FatStr);
            FoodType=JOptionPane.showInputDialog("Do you prefer a specific kind of food? ");
            AllergicIssues=JOptionPane.showInputDialog("Do you have any Allergic issues against any kind of food? ");
            GymGoal=JOptionPane.showInputDialog("Do you have a gym goal? ");
            String NumberOfMealsStr = JOptionPane.showInputDialog("How many meals do you want? ");
            NumberOfMeals=Integer.parseInt(NumberOfMealsStr);
            TotalPrice= (((int)Calories + (int)Carbs + (int)Fat) / 30 ) * NumberOfMeals;
            
        }
        
        
    }
    
    public void MealsMenuWithGivinNutri(int CalNum,int CarNum, int FaNum){
        Scanner input = new Scanner(System.in);
        String MealChoiseStr1 = JOptionPane.showInputDialog("1. 200G of meet with 100G of rice and 50G of pasta and salad&snacks 70SR\n"+
                "2. 200G of fried salmon fish and tuna with 100G of rice and sauces and salad&snacks 60SR\n"+
                "3. 100G of beans with rice and 100G of salad&Vegetarian snacks and drinks 50SR\n"+
                "4.Make a flexiable meal: \nType \"The number of the meal \" to continue");
        MealChoise=Integer.parseInt(MealChoiseStr1);
        if (MealChoise == 1){
            FoodType=JOptionPane.showInputDialog("Do you prefer a specific kind of food?");
            AllergicIssues=JOptionPane.showInputDialog("Do you have any Allergic issues against any kind of food? ");
            GymGoal=JOptionPane.showInputDialog("Do you have a gym goal? ");
            String NumberOfMealsStr = JOptionPane.showInputDialog("How many meals do you want? ");
            NumberOfMeals=Integer.parseInt(NumberOfMealsStr);
            Calories=CalNum;
            Carbs=CarNum*NumberOfMeals;
            Fat=FaNum*NumberOfMeals;
            TotalPrice = 70 * NumberOfMeals;
            
        }
        else if (MealChoise == 2){
            FoodType=JOptionPane.showInputDialog("Do you prefer a specific kind of food?");
            AllergicIssues=JOptionPane.showInputDialog("Do you have any Allergic issues against any kind of food? ");
            GymGoal=JOptionPane.showInputDialog("Do you have a gym goal? ");
            String NumberOfMealsStr = JOptionPane.showInputDialog("How many meals do you want? ");
            NumberOfMeals=Integer.parseInt(NumberOfMealsStr);
            Calories=CalNum;
            Carbs=CarNum*NumberOfMeals;
            Fat=FaNum*NumberOfMeals;
            TotalPrice =60 * NumberOfMeals;
            
        }
        else if ( MealChoise == 3){
            FoodType=JOptionPane.showInputDialog("Do you prefer a specific kind of food?");
            AllergicIssues=JOptionPane.showInputDialog("Do you have any Allergic issues against any kind of food? ");
            GymGoal=JOptionPane.showInputDialog("Do you have a gym goal? ");
            String NumberOfMealsStr = JOptionPane.showInputDialog("How many meals do you want? ");
            NumberOfMeals=Integer.parseInt(NumberOfMealsStr);
            Calories=CalNum;
            Carbs=CarNum*NumberOfMeals;
            Fat=FaNum*NumberOfMeals;
            TotalPrice =50 * NumberOfMeals;
            System.exit(0);
        }
        else if (MealChoise ==4){
            Calories= CalNum;
            Carbs= CarNum;
            Fat= FaNum;
            FoodType=JOptionPane.showInputDialog("Do you prefer a specific kind of food? ");
            AllergicIssues=JOptionPane.showInputDialog("Do you have any Allergic issues against any kind of food? ");
            GymGoal=JOptionPane.showInputDialog("Do you have a gym goal? ");
            String NumberOfMealsStr = JOptionPane.showInputDialog("How many meals do you want? ");
            NumberOfMeals=Integer.parseInt(NumberOfMealsStr);
            TotalPrice= (((int)Calories + (int)Carbs + (int)Fat) / 30 ) * NumberOfMeals;
            
        }
        
        
    }
    
    @Override   
    public String toString(){/////////////////////////////////////////////// toString method 
        String MealInfo=String.format("\nMealChoise is:"+MealChoise+"\n"+
                "The preferable food type is: "+FoodType+"\n"+
                "The gym goal if there is: "+GymGoal+"\n"+
                "The Allergic issues if there was: "+AllergicIssues+"\n"+
                "The wanted meals number is: "+NumberOfMeals+"\n"+
                "The number of calories is: "+Calories+"\n"+
                "The number of grams of carbs is: "+Carbs+"\n"+
                "The number of grams of fat is: "+Fat+"\n"+
                "---------------------------------------------------------");
        return MealInfo;
    }
    
}
