
package urmealmain;

//import java.util.*;
import javax.swing.*;
//import java.io.*;

public class Customer {
   
    ///////////////////////// Variables declaring
  private String CustomerName,CustomerAddress,CustomerCity;
  private long CustomerID;
  private double PhoneNumber,CustomerHeight,CustomerWeight;
  private int CustomerAge;
   ///////////////////////// Variables declaring
  
  public Customer() { ///////////////1st Counstractor
      NewCustomer(); //NewCustomer method 
     
   
  }
  
  public Customer(String name, long id, double MobileNumber){ //2nd Constractor
         
      //////////////////////////Variables intiallizing
      CustomerName=name;
      CustomerID=id;
      PhoneNumber=MobileNumber;
      //////////////////////////Variables intiallizing
      NewCustomerArg(CustomerName); //using NewCustomerArg method for the 2nd constactor's arguments.
      
     
  }
    
    public void NewCustomer(){ //1st constractor method
        
        /////////////////The input msg for the information.
        CustomerName= JOptionPane.showInputDialog("-Please enter your Full name: ");
       
        CustomerCity=JOptionPane.showInputDialog("Hey there "+ CustomerName + " Please enter your city: ");
        
        CustomerAddress=JOptionPane.showInputDialog("Please enter your address: ");
        
        String PhoneNumberStr = JOptionPane.showInputDialog("Please enter your PhoneNumber: ");
       PhoneNumber= Double.parseDouble(PhoneNumberStr);
        
        
        String CustomerAgeStr=JOptionPane.showInputDialog("How old are you Mr/Ms."+CustomerName+": ");
        CustomerAge= Integer.parseInt(CustomerAgeStr);
        while (CustomerAge>120 || CustomerAge <=0 ){
              String CustomerAgeStrWrong = JOptionPane.showInputDialog("Wrong age Mr/Ms."+CustomerName+" please try again: ");
        CustomerAge= Integer.parseInt(CustomerAgeStrWrong);
        }
       
              String CustomerIDStr= JOptionPane.showInputDialog("Please enter your National ID number: ");
        CustomerID= Integer.parseInt(CustomerIDStr);
        
                String CustomerHeightStr=JOptionPane.showInputDialog("Please enter your height\"In CM\": ");
                CustomerHeight=Double.parseDouble(CustomerHeightStr);
          while (CustomerHeight>300 || CustomerHeight <=0){
             String CustomerHeightStrWrong=JOptionPane.showInputDialog("Not valid height, please try again: ");
                CustomerHeight=Double.parseDouble(CustomerHeightStrWrong);
        }
      
         String CustomerWeightStr=JOptionPane.showInputDialog("Please enter your weight\"in Kilograms\": ");
                CustomerWeight=Double.parseDouble(CustomerWeightStr);
        
          while (CustomerWeight>200 || CustomerWeight <= 0){
            String CustomerWeightStrWrong=JOptionPane.showInputDialog("Not valid weight, please try again: ");
                CustomerWeight=Double.parseDouble(CustomerWeightStrWrong);
                
        }         
    }
       ////////////////////////////////////////////////////////The input msg for the information.
    
    
    public void NewCustomerArg(String Name){
       
        CustomerName= Name;
        
        ////////////////////////////////////////////////////////The input msg for the information.
         CustomerName= JOptionPane.showInputDialog("-Please enter your Full name: ");
        
         CustomerAddress=JOptionPane.showInputDialog("Please enter your address: ");
        
        String CustomerAgeStr=JOptionPane.showInputDialog("How old are you Mr/Ms."+CustomerName+": ");
        CustomerAge= Integer.parseInt(CustomerAgeStr);
        while (CustomerAge>120){
              String CustomerAgeStrWrong = JOptionPane.showInputDialog("Wrong age Mr/Ms."+CustomerName+" please try again: ");
        CustomerAge= Integer.parseInt(CustomerAgeStrWrong);
        }
        
         String CustomerHeightStr=JOptionPane.showInputDialog("Please enter your height\"In CM\": ");
                CustomerHeight=Double.parseDouble(CustomerHeightStr);
          while (CustomerHeight>300){
             String CustomerHeightStrWrong=JOptionPane.showInputDialog("Not valid height, please try again: ");
                CustomerHeight=Double.parseDouble(CustomerHeightStrWrong);
        }
        
        String CustomerWeightStr=JOptionPane.showInputDialog("Please enter your weight\"in Kilograms\": ");
                CustomerWeight=Double.parseDouble(CustomerWeightStr);
        
          while (CustomerWeight>200){
            String CustomerWeightStrWrong=JOptionPane.showInputDialog("Not valid weight, please try again: ");
                CustomerWeight=Double.parseDouble(CustomerWeightStrWrong);
                
        }       
    }
     ////////////////////////////////////////////////////////The input msg for the information.
    
    
     ////////////////////////////////////////////////////////The toString method
  @Override
    public String toString(){
       String CustomerInfo= String.format("\n\t                                  The Customer's information\n"
               +"\nThe Customer's name is: "+ CustomerName +
                "\nThe Customer's city: "+CustomerCity+"\nThe Customer's address: " + CustomerAddress +
               "\nThe Customer's Phone number: "+PhoneNumber +"\nThe Customer's age: "+ CustomerAge +" Years"+
               "\nThe Customer's ID: "+ CustomerID + "\nThe Customer's height: "+ CustomerHeight +"CM"+
               "\nThe Customer's weight: " + CustomerWeight +"Kg"+'\n');
       
       return CustomerInfo;
    }
    ////////////////////////////////////////////////////////The toString method
    public void setCustomerName(String NewName , Customer i){ // i stands for the object made from the customer class.
        i.CustomerName=NewName;
    }
    public void setCustomerPhoneNumber(long NewPhoneNumber, Customer i){
        i.PhoneNumber=NewPhoneNumber;
    }
    public void setCustomerAge(int NewAge, Customer i){
        i.CustomerAge=NewAge;
    }
    public void setCustomerAddress(String NewAddress, Customer i){
        i.CustomerAddress=NewAddress;
    }
    public void setCustomerCity(String NewCity, Customer i){
        i.CustomerCity=NewCity;
    }
    public void setCustomerID(long NewID, Customer i){
       i. CustomerID=NewID;
    }
    public void setCustomerHeight(double NewHeight, Customer i){
        i.CustomerHeight=NewHeight;
    }
    public void setCustomerWeight(double NewWeight, Customer i){
        i.CustomerWeight=NewWeight;
    }
    public String getCustomerName(){
        return CustomerName;
    }
    
    public double getCustomerPhoneNumber(){
        return PhoneNumber;
    }
    public int getCustomerAge(){
        return CustomerAge;
    }
    public String getCustomerAddress(){
        return CustomerAddress;
    }
    public String getCustomerCity(){
        return CustomerCity;
    }
    public long getCustomerID(){
        return CustomerID;
    }
    public double getCustomerHeight(){
        return CustomerHeight;
    }
    public double getCustomerWeight(){
        return CustomerWeight;
    }
    
}
